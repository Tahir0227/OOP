#include<iostream>
#include<iomanip>
using namespace std;

int main()
{
    int num1,num2;
    int add,sub,mul;
    float div;

    cout<<"Enter two numder:";
    cin>>num1 >>num2;
    
    add=num1+num2;
    sub=num1-num2;
    mul=num1*num2;
    div=(float)num1/num2;
    
    cout<<"Addition      :" <<" " <<setw(8) <<add;
    cout<<"\nSubstraction  :" <<" " <<setw(8) <<sub;
    cout<<"\nMultiplication:" <<" " <<setw(8) <<mul;
    cout<<"\nDivision      :" <<" " <<setw(8) <<(float)div;
   
}
