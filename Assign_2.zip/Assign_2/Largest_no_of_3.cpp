#include<iostream>
#include<iomanip>
using namespace std;

int main()
{
    int num1,num2,num3;
    int larger_no;

    cout<<"Enter three number:";
    cin>>num1 >>num2 >>num3;
    
    if(num1>=num2 && num1>=num3)
        larger_no=num1;
    else if(num2>=num1 && num2>=num3)
        larger_no=num2;
    else
        larger_no=num3;
        
    cout<<"Largest No : " <<larger_no;
   
}
