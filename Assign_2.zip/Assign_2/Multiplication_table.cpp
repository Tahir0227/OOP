#include<iostream>
#include<iomanip>
using namespace std;

int main()
{
    int num;
    int mul;

    cout<<"Enter number:";
    cin>>num;
    
    for(int i = 1; i <= 10; i++)
    {
        mul=i*num;
        cout<<setw(5) <<mul <<"\n";
    }
   
}
